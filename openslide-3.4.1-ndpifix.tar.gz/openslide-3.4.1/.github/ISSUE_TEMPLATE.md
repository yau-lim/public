## Context

**Issue type** (bug report or feature request): 
**Operating system** (e.g. Fedora 24, Mac OS 10.11, Windows 10): 
**Platform** (e.g. 64-bit x86, 32-bit ARM): 
**OpenSlide version**: 
**Slide format** (e.g. SVS, NDPI, MRXS): 

## Details

